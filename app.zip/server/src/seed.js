const { hashPassword } = require("./auth");
const { makeBarcode } = require("./barcode");

function daysAgo(n) {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d.toISOString();
}

function dateOffset(n) {
  const d = new Date();
  const day = d.getDay();
  const monday = new Date(d);
  monday.setDate(d.getDate() - ((day + 6) % 7) + n);
  return monday.toISOString().slice(0, 10);
}

const MEN = ["S", "M", "L", "XL", "XXL"];
const WOMEN = ["XS", "S", "M", "L", "XL"];
const CHILD = ["2-3Y", "4-5Y", "6-7Y", "8-9Y", "10-12Y"];

let pieceOrder = 0;

function piece(data) {
  const sortOrder = pieceOrder++;
  return {
    stock: 12,
    featured: false,
    grade: "A",
    sizes: MEN,
    occasions: ["Everyday"],
    // Seed catalog pieces are homepage/look imagery — not real floor stock.
    productKind: "display",
    sortOrder,
    ...data,
  };
}

/** Seed / demo catalog ids — marketing images moved to Home products, not inventory. */
const SEED_CATALOG_IDS = [
  "mens-oxford",
  "mens-polo",
  "mens-trouser",
  "mens-blazer",
  "mens-chino",
  "mens-knit",
  "womens-blouse",
  "womens-shirtdress",
  "womens-trouser",
  "womens-cardigan",
  "womens-dress",
  "womens-scarf",
  "boys-shirt",
  "boys-polo",
  "girls-dress",
  "girls-cardigan",
  "kids-chino",
  "kids-set",
  "womens-saree",
  "mens-panjabi",
  "mens-jeans",
  "unisex-tee",
  "womens-day-dress",
  "mens-casual-shirt",
];

function retailItem(seq, data) {
  const stamp = daysAgo(10);
  return {
    color: "",
    size: "",
    category: "",
    cost: 0,
    stock: 0,
    image: "",
    notes: "",
    createdAt: stamp,
    updatedAt: stamp,
    version: 1,
    ...data,
    id: `inv_seed${seq}`,
    barcode: makeBarcode(seq),
  };
}

/** Banner-icon categories that must resolve to shop products. */
function iconCategoryProducts() {
  return [
    piece({
      id: "womens-saree",
      name: "Everyday Soft Saree",
      audience: "Women",
      category: "Saree",
      slot: "dress",
      price: 4800,
      featured: true,
      sizes: ["Free"],
      colors: [{ name: "Ivory", hex: "#f3efe6" }],
      occasions: ["Everyday", "Weekend"],
      image: "/images/womens-saree.jpg",
      description:
        "Soft everyday saree in ivory — light drape and clean border finishing from Bangladesh’s woven programmes.",
      details: ["Soft weave", "Bangladesh Grade A export", "Saree programme", "Dry clean preferred"],
    }),
    piece({
      id: "mens-panjabi",
      name: "Classic Cotton Panjabi",
      audience: "Men",
      category: "Panjabi",
      slot: "top",
      price: 2650,
      featured: true,
      stock: 18,
      colors: [{ name: "White", hex: "#f7f7f5" }],
      occasions: ["Everyday", "Weekend"],
      image: "/images/mens-panjabi.jpg",
      description:
        "Straight-cut cotton panjabi with a clean placket and side vents — Grade A casual finishing for everyday wear.",
      details: ["Cotton", "Bangladesh Grade A export", "Panjabi programme", "Machine wash cold"],
    }),
    piece({
      id: "mens-jeans",
      name: "Export Slim Jeans",
      audience: "Men",
      category: "Jeans",
      slot: "bottom",
      price: 3200,
      featured: true,
      stock: 20,
      colors: [{ name: "Indigo", hex: "#2c3a5a" }],
      occasions: ["Everyday", "Weekend"],
      image: "/images/mens-jeans.jpg",
      description:
        "Slim indigo jeans from Bangladesh denim programmes — soft hand, clean seams, everyday rise.",
      details: ["Cotton denim", "Bangladesh Grade A export", "Jeans programme", "Machine wash cold"],
    }),
    piece({
      id: "unisex-tee",
      name: "Soft Jersey T-Shirt",
      audience: "Unisex",
      category: "T-Shirt",
      slot: "top",
      price: 950,
      featured: true,
      stock: 40,
      colors: [
        { name: "White", hex: "#f7f7f5" },
        { name: "Ivory", hex: "#f3efe6" },
      ],
      occasions: ["Everyday", "Weekend", "Travel"],
      image: "/images/unisex-tee.jpg",
      description:
        "Soft jersey T-shirt with taped shoulders and a clean neck rib — everyday knit from Bangladesh export floors.",
      details: ["Cotton jersey", "Bangladesh Grade A export", "T-Shirt programme", "Machine wash cold"],
    }),
    piece({
      id: "womens-day-dress",
      name: "Easy Cotton Dress",
      audience: "Women",
      category: "Dress",
      slot: "dress",
      price: 3600,
      featured: true,
      sizes: WOMEN,
      colors: [{ name: "Stone", hex: "#cfc6ba" }],
      occasions: ["Everyday", "Weekend"],
      image: "/images/womens-shirtdress.jpg",
      description:
        "Easy cotton day dress with a soft waist — pairs with the banner Dress edit from Bangladesh casual programmes.",
      details: ["Cotton", "Bangladesh Grade A export", "Dress programme", "Machine wash cold"],
    }),
    piece({
      id: "mens-casual-shirt",
      name: "Everyday Casual Shirt",
      audience: "Men",
      category: "Shirt",
      slot: "top",
      price: 2100,
      featured: true,
      stock: 22,
      colors: [{ name: "Sky", hex: "#8eafc6" }],
      occasions: ["Everyday", "Weekend"],
      image: "/images/mens-oxford.jpg",
      description:
        "Light casual shirt in sky cotton — set collar and clean yoke for the banner Shirt edit.",
      details: ["Cotton", "Bangladesh Grade A export", "Shirt programme", "Machine wash cold"],
    }),
  ];
}

/** Upsert banner-icon products into an existing database and keep images in sync. */
function ensureIconCategoryProducts(db) {
  if (!Array.isArray(db.products)) db.products = [];
  let changed = false;
  const extras = iconCategoryProducts();
  const maxSort = db.products.reduce((max, product) => {
    const order = Number.isFinite(product.sortOrder) ? product.sortOrder : 0;
    return Math.max(max, order);
  }, 0);
  extras.forEach((product, index) => {
    const existing = db.products.find((entry) => entry.id === product.id);
    if (!existing) {
      db.products.push({
        ...product,
        productKind: "display",
        sortOrder: maxSort + index + 1,
        featured: product.featured !== false,
      });
      changed = true;
      return;
    }
    if (existing.productKind !== "display") {
      existing.productKind = "display";
      changed = true;
    }
    ["image", "name", "category", "audience", "description"].forEach((key) => {
      if (product[key] && existing[key] !== product[key]) {
        existing[key] = product[key];
        changed = true;
      }
    });
  });

  const needed = [
    { name: "Saree", audiences: ["Women"] },
    { name: "Panjabi", audiences: ["Men", "Children"] },
    { name: "Dress", audiences: ["Women", "Children"] },
    { name: "Jeans", audiences: ["Men", "Women", "Children", "Unisex"] },
    { name: "Shirt", audiences: ["Men", "Women", "Children", "Unisex"] },
    { name: "T-Shirt", audiences: ["Men", "Women", "Children", "Unisex"] },
    { name: "Shirts", audiences: ["Men", "Women", "Children", "Unisex"] },
    { name: "Dresses", audiences: ["Women", "Children"] },
  ];
  if (!Array.isArray(db.inventoryCategories)) db.inventoryCategories = [];
  needed.forEach((entry) => {
    const index = db.inventoryCategories.findIndex(
      (item) => String(typeof item === "string" ? item : item.name).toLowerCase() === entry.name.toLowerCase()
    );
    if (index < 0) {
      db.inventoryCategories.push(entry);
      changed = true;
      return;
    }
    const current = db.inventoryCategories[index];
    if (typeof current === "string") {
      db.inventoryCategories[index] = entry;
      changed = true;
    } else if (!Array.isArray(current.audiences) || !current.audiences.length) {
      current.audiences = entry.audiences.slice();
      changed = true;
    }
  });
  return changed;
}

function buildSeed() {
  pieceOrder = 0;
  const clientPass = hashPassword("style123");
  const adminPass = hashPassword("style123");

  const products = [
    piece({
      id: "mens-oxford",
      name: "Casual Export Oxford",
      audience: "Men",
      category: "Shirts",
      slot: "top",
      price: 2450,
      featured: true,
      stock: 24,
      colors: [
        { name: "White", hex: "#f7f7f5" },
        { name: "Sky", hex: "#8eafc6" },
      ],
      occasions: ["Everyday", "Weekend"],
      image: "/images/mens-oxford.jpg",
      description:
        "A Grade A woven oxford from Bangladesh’s casual shirt programmes — set collar, clean yoke, soft hand. Built for export floors, cut for everyday wear.",
      details: ["100% cotton oxford", "Bangladesh Grade A export", "Casual RMG programme", "Machine wash cold"],
    }),
    piece({
      id: "mens-polo",
      name: "Export Pique Polo",
      audience: "Men",
      category: "Knitwear",
      slot: "top",
      price: 1650,
      featured: true,
      stock: 30,
      colors: [
        { name: "Navy", hex: "#1c2433" },
        { name: "White", hex: "#f7f7f5" },
      ],
      occasions: ["Weekend", "Everyday", "Travel"],
      image: "/images/mens-polo.jpg",
      description:
        "Compact pique polo with export-floor stitch density and a rib that holds after wash. The everyday knit Bangladesh factories ship worldwide.",
      details: ["Cotton pique", "Bangladesh Grade A export", "Casual knit programme", "Two-button placket"],
    }),
    piece({
      id: "mens-trouser",
      name: "Casual Twill Trouser",
      audience: "Men",
      category: "Trousers",
      slot: "bottom",
      price: 2950,
      featured: true,
      colors: [{ name: "Charcoal", hex: "#3d3d3d" }],
      occasions: ["Everyday", "Weekend"],
      image: "/images/mens-trouser.jpg",
      description:
        "Flat-front casual trouser in export twill — soft rise, clean seams, no stiff dress crease. Made for all-day wear with polos and oxfords.",
      details: ["Cotton-rich twill", "Bangladesh Grade A export", "Casual bottom programme", "Machine wash"],
    }),
    piece({
      id: "mens-blazer",
      name: "Soft Casual Overshirt",
      audience: "Men",
      category: "Outerwear",
      slot: "layer",
      price: 4800,
      featured: true,
      stock: 12,
      colors: [{ name: "Navy", hex: "#1c2433" }],
      occasions: ["Weekend", "Travel", "Everyday"],
      image: "/images/mens-blazer.jpg",
      description:
        "Unstructured overshirt layer from Bangladesh’s casual outerwear lines — light shoulder, easy buttons, thrown over a polo or tee.",
      details: ["Cotton blend", "Bangladesh Grade A export", "Casual layer programme", "Machine wash cold"],
    }),
    piece({
      id: "mens-chino",
      name: "Garment-Wash Chino",
      audience: "Men",
      category: "Trousers",
      slot: "bottom",
      price: 2200,
      featured: true,
      colors: [{ name: "Sand", hex: "#d9c7a6" }],
      occasions: ["Weekend", "Travel", "Everyday"],
      image: "/images/mens-chino.jpg",
      description:
        "Garment-washed chino from the Bangladesh export chino programme: even dye, clean seams, soft hand for weekends and travel.",
      details: ["Cotton twill", "Bangladesh Grade A export", "Casual chino programme", "Machine wash"],
    }),
    piece({
      id: "mens-knit",
      name: "Everyday Crew Knit",
      audience: "Men",
      category: "Knitwear",
      slot: "top",
      price: 2400,
      colors: [{ name: "Camel", hex: "#c4a574" }],
      occasions: ["Weekend", "Travel", "Everyday"],
      image: "/images/mens-knit.jpg",
      description:
        "Fine-gauge crew knit for cooler evenings — export gauge control, short rib, easy under an overshirt or alone.",
      details: ["Cotton-rich knit", "Bangladesh Grade A export", "Casual knit programme", "Hand wash"],
    }),
    piece({
      id: "womens-blouse",
      name: "Soft Poplin Shirt",
      audience: "Women",
      category: "Shirts",
      slot: "top",
      price: 2150,
      featured: true,
      sizes: WOMEN,
      colors: [{ name: "Ivory", hex: "#f3efe6" }],
      occasions: ["Everyday", "Weekend"],
      image: "/images/womens-blouse.jpg",
      description:
        "Ivory poplin casual shirt with a soft collar and covered placket — Bangladesh export shirting cloth cut for everyday ease.",
      details: ["Cotton poplin", "Bangladesh Grade A export", "Casual shirt programme", "Machine wash cold"],
    }),
    piece({
      id: "womens-shirtdress",
      name: "Everyday Shirt Dress",
      audience: "Women",
      category: "Dresses",
      slot: "dress",
      price: 4200,
      featured: true,
      sizes: WOMEN,
      colors: [{ name: "Stone", hex: "#cfc6ba" }],
      occasions: ["Everyday", "Weekend"],
      image: "/images/womens-shirtdress.jpg",
      description:
        "Knee-length casual shirt dress in stone cotton with a self belt — one piece from Bangladesh’s export dress lines for errands and weekends.",
      details: ["Cotton poplin", "Bangladesh Grade A export", "Casual dress programme", "Machine wash cold"],
    }),
    piece({
      id: "womens-trouser",
      name: "Soft Wide Casual Trouser",
      audience: "Women",
      category: "Trousers",
      slot: "bottom",
      price: 2750,
      sizes: WOMEN,
      colors: [{ name: "Stone", hex: "#cfc6ba" }],
      occasions: ["Everyday", "Weekend"],
      image: "/images/womens-trouser.jpg",
      description:
        "Easy wide-leg casual trouser with a clean waist — pairs with the poplin shirt for a full export-casual look.",
      details: ["Soft weave", "Bangladesh Grade A export", "Casual bottom programme", "Machine wash cold"],
    }),
    piece({
      id: "womens-cardigan",
      name: "Light Layer Cardigan",
      audience: "Women",
      category: "Knitwear",
      slot: "layer",
      price: 3100,
      sizes: WOMEN,
      colors: [{ name: "Forest", hex: "#2f4f3e" }],
      occasions: ["Everyday", "Travel"],
      image: "/images/womens-cardigan.jpg",
      description:
        "Light forest cardigan with narrow rib — same gauge control as Bangladesh export knit orders, made for everyday layering.",
      details: ["Fine knit", "Bangladesh Grade A export", "Casual knit programme", "Hand wash"],
    }),
    piece({
      id: "womens-dress",
      name: "Soft Midi Casual Dress",
      audience: "Women",
      category: "Dresses",
      slot: "dress",
      price: 5200,
      featured: true,
      stock: 10,
      sizes: WOMEN,
      colors: [{ name: "Midnight", hex: "#1c2433" }],
      occasions: ["Weekend", "Everyday"],
      image: "/images/womens-dress.jpg",
      description:
        "Soft midi dress in midnight cloth — covered neckline, easy sleeves, Grade A casual finishing for dinners out and city evenings.",
      details: ["Soft crepe blend", "Bangladesh Grade A export", "Casual dress programme", "Dry clean preferred"],
    }),
    piece({
      id: "womens-scarf",
      name: "Accent Knit Scarf",
      audience: "Women",
      category: "Accessories",
      slot: "accessory",
      price: 950,
      sizes: ["One"],
      colors: [{ name: "Rust", hex: "#b85c38" }],
      occasions: ["Everyday", "Travel"],
      image: "/images/womens-scarf.jpg",
      description:
        "Rust knit scarf with finished edges — one clear casual accent against ivory, navy, or stone.",
      details: ["Knit blend", "Bangladesh Grade A export", "Casual accessory", "Hand wash"],
    }),
    piece({
      id: "boys-shirt",
      name: "Boys Casual Export Shirt",
      audience: "Children",
      category: "Shirts",
      slot: "top",
      price: 1250,
      featured: true,
      sizes: CHILD,
      colors: [{ name: "White", hex: "#f7f7f5" }],
      occasions: ["Everyday", "Weekend"],
      image: "/images/boys-shirt.jpg",
      description:
        "Child-sized woven shirt on the same Grade A casual programme as the men’s oxford — even collar, matched buttons, clean seams.",
      details: ["Cotton poplin", "Bangladesh Grade A export", "Kids casual programme", "Ages 2–12"],
    }),
    piece({
      id: "boys-polo",
      name: "Boys Casual Polo",
      audience: "Children",
      category: "Knitwear",
      slot: "top",
      price: 1150,
      sizes: CHILD,
      colors: [{ name: "Sky", hex: "#8eafc6" }],
      occasions: ["Weekend", "Everyday"],
      image: "/images/boys-polo.jpg",
      description:
        "Sky pique polo in children’s sizing — rib collar and taped shoulder checked to Bangladesh export knit standards.",
      details: ["Cotton pique", "Bangladesh Grade A export", "Kids casual programme", "Ages 2–12"],
    }),
    piece({
      id: "girls-dress",
      name: "Girls Everyday Cotton Dress",
      audience: "Children",
      category: "Dresses",
      slot: "dress",
      price: 1650,
      featured: true,
      sizes: CHILD,
      colors: [{ name: "Ivory", hex: "#f3efe6" }],
      occasions: ["Everyday", "Weekend"],
      image: "/images/girls-dress.jpg",
      description:
        "Modest knee-length dress in ivory cotton with a set waist — simple casual Grade A for school days and family weekends.",
      details: ["Cotton", "Bangladesh Grade A export", "Kids casual programme", "Ages 2–12"],
    }),
    piece({
      id: "girls-cardigan",
      name: "Girls Soft Cardigan",
      audience: "Children",
      category: "Knitwear",
      slot: "layer",
      price: 1450,
      sizes: CHILD,
      colors: [{ name: "Camel", hex: "#c4a574" }],
      occasions: ["Everyday", "Travel"],
      image: "/images/girls-cardigan.jpg",
      description:
        "Camel cardigan in a child gauge — flat buttons and a rib that recovers after wash, from Bangladesh kids knit programmes.",
      details: ["Cotton knit", "Bangladesh Grade A export", "Kids casual programme", "Ages 2–12"],
    }),
    piece({
      id: "kids-chino",
      name: "Kids Soft Chino",
      audience: "Children",
      category: "Trousers",
      slot: "bottom",
      price: 1100,
      sizes: CHILD,
      colors: [{ name: "Stone", hex: "#cfc6ba" }],
      occasions: ["Everyday", "Weekend"],
      image: "/images/kids-chino.jpg",
      description:
        "Stone chinos in children’s sizing with a soft waistband — same twill family as the men’s casual chino programme.",
      details: ["Cotton twill", "Bangladesh Grade A export", "Kids casual programme", "Ages 2–12"],
    }),
    piece({
      id: "kids-set",
      name: "Kids Polo & Short Set",
      audience: "Children",
      category: "Sets",
      slot: "top",
      price: 1550,
      featured: true,
      sizes: CHILD,
      colors: [{ name: "Navy", hex: "#1c2433" }],
      occasions: ["Weekend", "Travel"],
      image: "/images/kids-set.jpg",
      description:
        "Navy polo with stone shorts as a matched casual set — one Grade A outfit without building piece by piece.",
      details: ["Cotton pique and twill", "Bangladesh Grade A export", "Kids casual programme", "Ages 2–12"],
    }),
    ...iconCategoryProducts(),
  ];

  const looks = [
    {
      id: "mens-office",
      name: "City Casual",
      occasion: "Everyday",
      audience: "Men",
      image: "/images/look-men-office.jpg",
      summary: "Soft overshirt, oxford, casual twill trouser.",
      note: "Bangladesh export casuals for a Dhaka day out — keep colour quiet.",
      productIds: ["mens-blazer", "mens-oxford", "mens-trouser"],
    },
    {
      id: "womens-day",
      name: "Easy Day Dress",
      occasion: "Everyday",
      audience: "Women",
      image: "/images/look-women-day.jpg",
      summary: "Shirt dress with the light cardigan.",
      note: "One dress, one knit — enough for errands and a late coffee.",
      productIds: ["womens-shirtdress", "womens-cardigan"],
    },
    {
      id: "childrens-edit",
      name: "Kids Casual Edit",
      occasion: "Everyday",
      audience: "Children",
      image: "/images/look-children.jpg",
      summary: "Boys shirt, kids chino, girls dress, camel cardigan.",
      note: "Grade A kids casuals, sized from 2–3Y to 10–12Y.",
      productIds: ["boys-shirt", "kids-chino", "girls-dress", "girls-cardigan"],
    },
    {
      id: "evening-column",
      name: "Evening Easy",
      occasion: "Weekend",
      audience: "Women",
      image: "/images/look-evening.jpg",
      summary: "Soft midi dress and a rust scarf.",
      note: "Casual evening polish — covered neckline, one accent colour.",
      productIds: ["womens-dress", "womens-scarf"],
    },
    {
      id: "weekend-ease",
      name: "Weekend Ease",
      occasion: "Weekend",
      audience: "Men",
      image: "/images/look-weekend.jpg",
      summary: "Navy polo, sand chino, camel knit nearby.",
      note: "Friday lunch to travel days — core Bangladesh export casuals.",
      productIds: ["mens-polo", "mens-chino", "mens-knit"],
    },
  ];

  const inventoryItems = [
    retailItem(1001, {
      sku: "SA-OXF-WHT-M",
      name: "Casual Export Oxford",
      color: "White",
      size: "M",
      category: "Shirts",
      price: 2450,
      cost: 1480,
      stock: 18,
      notes: "Shop-floor Grade A oxford.",
    }),
    retailItem(1002, {
      sku: "SA-POL-NVY-L",
      name: "Export Pique Polo",
      color: "Navy",
      size: "L",
      category: "Knitwear",
      price: 1650,
      cost: 960,
      stock: 24,
    }),
    retailItem(1003, {
      sku: "SA-CHN-SND-32",
      name: "Garment-Wash Chino",
      color: "Sand",
      size: "32",
      category: "Trousers",
      price: 2200,
      cost: 1310,
      stock: 12,
    }),
    retailItem(1004, {
      sku: "SA-SCF-RST-OS",
      name: "Accent Knit Scarf",
      color: "Rust",
      size: "One",
      category: "Accessories",
      price: 950,
      cost: 520,
      stock: 3,
      notes: "Low stock sample.",
    }),
  ];

  const homeCollections = [
    {
      id: "men",
      audience: "Men",
      kicker: "Men",
      title: "Polos, shirts, chinos",
      image: "/images/look-weekend.jpg",
    },
    {
      id: "women",
      audience: "Women",
      kicker: "Women",
      title: "Blouses, easy dresses, knits",
      image: "/images/look-women-day.jpg",
    },
    {
      id: "children",
      audience: "Children",
      kicker: "Children",
      title: "Same Grade A, ages 2–12",
      image: "/images/look-children.jpg",
    },
  ];

  return {
    users: [
      {
        id: "u_farhan",
        name: "Farhan Ahmed",
        email: "farhan@stylearz.com",
        role: "customer",
        ...clientPass,
        wishlist: ["mens-blazer", "womens-scarf"],
        preferences: null,
        createdAt: daysAgo(40),
      },
      {
        id: "u_admin",
        name: "Studio Admin",
        email: "admin@stylearz.com",
        role: "admin",
        ...adminPass,
        wishlist: [],
        preferences: null,
        createdAt: daysAgo(40),
      },
    ],
    products,
    looks,
    homeCollections,
    inventoryItems,
    inventorySeq: 1004,
    inventoryDeleted: [],
    inventoryCategories: [
      { name: "Saree", audiences: ["Women"] },
      { name: "Panjabi", audiences: ["Men", "Children"] },
      { name: "Dress", audiences: ["Women", "Children"] },
      { name: "Jeans", audiences: ["Men", "Women", "Children", "Unisex"] },
      { name: "Shirt", audiences: ["Men", "Women", "Children", "Unisex"] },
      { name: "T-Shirt", audiences: ["Men", "Women", "Children", "Unisex"] },
      { name: "Shirts", audiences: ["Men", "Women", "Children", "Unisex"] },
      { name: "Knitwear", audiences: ["Men", "Women", "Children", "Unisex"] },
      { name: "Trousers", audiences: ["Men", "Women", "Children", "Unisex"] },
      { name: "Outerwear", audiences: ["Men", "Women", "Children", "Unisex"] },
      { name: "Dresses", audiences: ["Women", "Children"] },
      { name: "Sets", audiences: ["Children", "Unisex"] },
      { name: "Accessories", audiences: ["Men", "Women", "Children", "Unisex"] },
    ],
    posSessions: [],
    posScanEvents: [],
    posSales: [],
    orders: [
      {
        id: "SA-18420",
        userId: "u_farhan",
        email: "farhan@stylearz.com",
        name: "Farhan Ahmed",
        phone: "+880 1700 000000",
        address: "House 18, Road 12, Gulshan 1",
        city: "Dhaka",
        country: "Bangladesh",
        notes: "",
        items: [
          {
            productId: "mens-oxford",
            name: "Export Oxford Shirt",
            price: 2450,
            qty: 1,
            size: "M",
            color: "White",
            image: "/images/mens-oxford.jpg",
          },
        ],
        subtotal: 2450,
        shipping: 120,
        total: 2570,
        paymentLast4: "4242",
        status: "shipped",
        createdAt: daysAgo(6),
      },
    ],
    wardrobe: [
      {
        id: "w_shirt",
        userId: "u_farhan",
        name: "White office shirt",
        category: "Shirts",
        color: "White",
        hex: "#f5f5f2",
        notes: "Already in the cupboard. Pairs with charcoal.",
      },
      {
        id: "w_jean",
        userId: "u_farhan",
        name: "Indigo straight jean",
        category: "Trousers",
        color: "Indigo",
        hex: "#2c3e6b",
        notes: "Clean hem.",
      },
      {
        id: "w_jacket",
        userId: "u_farhan",
        name: "Navy lightweight jacket",
        category: "Outerwear",
        color: "Navy",
        hex: "#1e2a44",
        notes: "Useful over the polo on cooler evenings.",
      },
    ],
    outfits: [
      {
        id: "o_board",
        userId: "u_farhan",
        name: "Gulshan meetings",
        slots: {
          layer: "mens-blazer",
          top: "mens-oxford",
          bottom: "mens-trouser",
        },
        createdAt: daysAgo(3),
      },
    ],
    planner: [
      {
        id: "pl_mon",
        userId: "u_farhan",
        date: dateOffset(0),
        title: "Office uniform",
        outfitId: "o_board",
        notes: "Client meetings in Gulshan",
        wornCount: 2,
        lastWorn: daysAgo(7),
      },
      {
        id: "pl_wed",
        userId: "u_farhan",
        date: dateOffset(2),
        title: "Polo and chino",
        outfitId: null,
        notes: "Site visit",
        wornCount: 0,
        lastWorn: null,
      },
      {
        id: "pl_sat",
        userId: "u_farhan",
        date: dateOffset(5),
        title: "Family lunch",
        outfitId: null,
        notes: "Kids casual edit, overshirt for Farhan",
        wornCount: 1,
        lastWorn: daysAgo(14),
      },
    ],
    posts: [
      {
        id: "post_1",
        userId: "u_farhan",
        author: "Farhan Ahmed",
        title: "White oxford, soft overshirt, Gulshan traffic",
        body: "The casual export oxford still looked clean at 6pm. That is the point of Grade A RMG.",
        image: "/images/community-1.jpg",
        likes: 18,
        likedBy: [],
        status: "published",
        createdAt: daysAgo(2),
      },
      {
        id: "post_2",
        userId: null,
        author: "Nusrat Rahman",
        title: "Stone shirt dress, forest cardigan",
        body: "Wore the everyday shirt dress for errands and added the cardigan for the evening call.",
        image: "/images/community-2.jpg",
        likes: 11,
        likedBy: [],
        status: "published",
        createdAt: daysAgo(4),
      },
      {
        id: "post_3",
        userId: null,
        author: "StyleARZ Studio",
        title: "What Grade A casuals look like on the rail",
        body: "Matched collars, even dye, buttons that sit flat — Bangladesh export-floor standard, edited for everyday casuals.",
        image: "/images/community-3.jpg",
        likes: 24,
        likedBy: [],
        status: "published",
        createdAt: daysAgo(8),
      },
    ],
    notifications: [
      {
        id: "n1",
        userId: "u_farhan",
        title: "Order SA-18420 is on the way",
        body: "Casual Export Oxford has left the floor for Gulshan.",
        read: false,
        createdAt: daysAgo(2),
      },
      {
        id: "n2",
        userId: "u_farhan",
        title: "Children’s edit is ready",
        body: "Grade A shirts, dresses, and knits are sized from 2–3Y to 10–12Y.",
        read: false,
        createdAt: daysAgo(5),
      },
      {
        id: "n3",
        userId: "u_farhan",
        title: "Delivery across Bangladesh",
        body: "Orders of ৳8,000 and above ship complimentary inside Bangladesh.",
        read: true,
        createdAt: daysAgo(9),
      },
    ],
  };
}

/**
 * Move seeded marketing catalog into Home products (display) and drop inventory
 * rows that were imported from those fakes — real floor stock stays.
 */
function ensureFakeCatalogMovedToHome(db) {
  if (!Array.isArray(db.products)) db.products = [];
  if (!Array.isArray(db.inventoryItems)) db.inventoryItems = [];
  let changed = false;
  const seedIds = new Set(SEED_CATALOG_IDS);

  db.products.forEach((product) => {
    if (!product || !seedIds.has(product.id)) return;
    if (product.productKind !== "display") {
      product.productKind = "display";
      changed = true;
    }
    // Keep homepage featured picks visible after the move.
    if (product.featured == null) {
      product.featured = true;
      changed = true;
    }
  });

  const before = db.inventoryItems.length;
  db.inventoryItems = db.inventoryItems.filter((item) => {
    if (!item || !item.sourceProductId) return true;
    return !seedIds.has(item.sourceProductId);
  });
  if (db.inventoryItems.length !== before) changed = true;

  return changed;
}

module.exports = {
  buildSeed,
  ensureIconCategoryProducts,
  ensureFakeCatalogMovedToHome,
  iconCategoryProducts,
  SEED_CATALOG_IDS,
};
